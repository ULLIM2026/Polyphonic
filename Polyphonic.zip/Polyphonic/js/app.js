/* ========================================
   Polyphonic — 음악 아카이빙 앱
   app.js  |  React (CDN + Babel Standalone)
   ======================================== */

const { useState, useEffect, useMemo } = React;

/* ── Design System ── */
const ACCENT       = "#D94F3D";
const ACCENT_LIGHT = "#fdf1f0";
const BORDER       = "#e8e8e8";

const globalStyle = `
    @import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/static/pretendard.css');
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Pretendard', sans-serif; background: #fff; color: #111; -webkit-font-smoothing: antialiased; overscroll-behavior: none; }

    .scroll-container::-webkit-scrollbar { width: 3px; }
    .scroll-container::-webkit-scrollbar-thumb { background: #ccc; border-radius: 2px; }

    header { border-bottom: 1px solid ${BORDER}; position: sticky; top: 0; z-index: 100; background: #fff; }
    .grid-layout { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; padding: 20px; }
    .grid-card { cursor: pointer; text-align: center; }
    .grid-img { width: 100%; aspect-ratio: 1/1; border-radius: 12px; object-fit: cover; border: 1px solid ${BORDER}; background: #f9f9f9; }

    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: flex-end; }
    .modal-content { background: #fff; width: 100%; max-width: 600px; margin: 0 auto; border-top-left-radius: 25px; border-top-right-radius: 25px; max-height: 94vh; overflow-y: auto; padding: 25px; }

    .section-label { font-size: 10px; color: #999; font-weight: 800; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
    .concept-card { padding: 20px; border: 1px solid ${BORDER}; border-radius: 12px; margin: 0 20px 10px; cursor: pointer; }
    .accordion { margin-top: 15px; background: #f9f9f9; padding: 20px; border-radius: 15px; line-height: 1.7; white-space: pre-wrap; font-size: 14px; }

    .search-container { padding: 15px 20px; background: #fff; border-bottom: 1px solid ${BORDER}; }
    .search-input { width: 100%; padding: 12px 15px; border-radius: 10px; border: 1px solid ${BORDER}; background: #f5f5f5; outline: none; font-size: 14px; transition: all 0.2s; }
    .search-input:focus { border-color: ${ACCENT}; background: #fff; }
    .search-results { padding: 10px 20px; background: #fff; position: absolute; width: 100%; max-width: 720px; z-index: 90; box-shadow: 0 10px 20px rgba(0,0,0,0.05); }
    .search-item { padding: 12px 0; border-bottom: 1px solid #f0f0f0; cursor: pointer; }
    .search-tag { display: inline-block; font-size: 9px; padding: 2px 6px; border-radius: 4px; background: ${ACCENT_LIGHT}; color: ${ACCENT}; font-weight: 700; margin-right: 8px; vertical-align: middle; }

    .hashtag-link { color: ${ACCENT}; font-weight: 700; cursor: pointer; margin-right: 8px; text-decoration: none; }
    .hashtag-link:hover { text-decoration: underline; }
    .hashtag-group-title { font-size: 12px; font-weight: 800; color: #333; margin: 25px 0 10px; padding-left: 10px; border-left: 3px solid ${ACCENT}; }
`;

/* ── Data Schemas (기본값) ── */
const EMPTY_MUSIC = {
    id: null, filmTitle: "", musicTitle: "", date: "", link: "",
    composer: "", year: "", genre: "", context: "", function: "",
    review: "", questions: "", scraps: "", anecdotes: "", hashtags: "",
    composition: { melody: "", harmony: "", rhythm: "", timbre: "", dynamics: "" }
};
const EMPTY_COMPOSER   = { id: null, name: "", photo: null, description: "", traits: "", workIds: [], anecdotes: "", scraps: "", hashtags: "" };
const EMPTY_GENRE      = { id: null, name: "", photo: null, summary: "", traits: "", anecdotes: "", scraps: "", hashtags: "" };
const EMPTY_INSTRUMENT = { id: null, name: "", photo: null, summary: "", detail: "", traits: "", usage: "", artist: "", anecdotes: "", scraps: "", hashtags: "" };
const EMPTY_CONCEPT    = { id: null, name: "", summary: "", detail: "", usage: "", anecdotes: "", scraps: "", hashtags: "" };

/* ── localStorage helpers ── */
function load(key, fallback = []) {
    try { return JSON.parse(localStorage.getItem(key)) || fallback; }
    catch { return fallback; }
}
function save(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
}

/* ══════════════════════════════════════
   메인 앱 컴포넌트
══════════════════════════════════════ */
function Polyphonic() {
    const [activeTab,    setActiveTab]    = useState("library");
    const [view,         setView]         = useState("list");
    const [searchQuery,  setSearchQuery]  = useState("");
    const [targetHashtag, setTargetHashtag] = useState("");

    // ── 데이터 상태 (localStorage 연동) ──
    const [musics,      setMusics]      = useState(() => load('p_musics'));
    const [composers,   setComposers]   = useState(() => load('p_composers'));
    const [genres,      setGenres]      = useState(() => load('p_genres'));
    const [instruments, setInstruments] = useState(() => load('p_instruments'));
    const [concepts,    setConcepts]    = useState(() => load('p_concepts'));

    useEffect(() => { save('p_musics',      musics);      }, [musics]);
    useEffect(() => { save('p_composers',   composers);   }, [composers]);
    useEffect(() => { save('p_genres',      genres);      }, [genres]);
    useEffect(() => { save('p_instruments', instruments); }, [instruments]);
    useEffect(() => { save('p_concepts',    concepts);    }, [concepts]);

    // ── 모달 & 폼 상태 ──
    const [showModal, setShowModal] = useState({ music: false, comp: false, genre: false, instrument: false, concept: false });
    const [forms, setForms] = useState({ music: EMPTY_MUSIC, comp: EMPTY_COMPOSER, genre: EMPTY_GENRE, instrument: EMPTY_INSTRUMENT, concept: EMPTY_CONCEPT });
    const [selectedItem, setSelectedItem] = useState(null);
    const [showCompositionLayer, setShowCompositionLayer] = useState(false);

    // ── 검색 결과 ──
    const searchResults = useMemo(() => {
        if (!searchQuery.trim()) return [];
        const q = searchQuery.toLowerCase();
        const all = [
            ...musics.map(m     => ({ ...m,  _type: 'library',    _title: m.musicTitle })),
            ...composers.map(c  => ({ ...c,  _type: 'composer',   _title: c.name })),
            ...genres.map(g     => ({ ...g,  _type: 'genre',      _title: g.name })),
            ...instruments.map(i=> ({ ...i,  _type: 'instrument', _title: i.name })),
            ...concepts.map(cp  => ({ ...cp, _type: 'concept',    _title: cp.name }))
        ];
        return all.filter(item => {
            const title   = (item._title || "").toLowerCase();
            const content = Object.values(item)
                .filter(v => typeof v === 'string' && !v.startsWith('data:image'))
                .join(" ").toLowerCase();
            return title.includes(q) || content.includes(q);
        });
    }, [searchQuery, musics, composers, genres, instruments, concepts]);

    // ── 해시태그 필터 ──
    const hashtagFilteredData = useMemo(() => {
        if (!targetHashtag) return { library: [], composer: [], genre: [], instrument: [], concept: [] };
        const check = (item) => (item.hashtags || "").split(" ").some(h => h === targetHashtag || h === `#${targetHashtag}`);
        return {
            library:    musics.filter(check),
            composer:   composers.filter(check),
            genre:      genres.filter(check),
            instrument: instruments.filter(check),
            concept:    concepts.filter(check)
        };
    }, [targetHashtag, musics, composers, genres, instruments, concepts]);

    // ── 이미지 업로드 ──
    const handleImgUpload = (e, type) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => setForms(prev => ({ ...prev, [type]: { ...prev[type], photo: reader.result } }));
            reader.readAsDataURL(file);
        }
    };

    // ── 추가 모달 열기 ──
    const openAddModal = () => {
        const keyMap    = { library: 'music', composer: 'comp', genre: 'genre', instrument: 'instrument', concept: 'concept' };
        const emptyMap  = { music: EMPTY_MUSIC, comp: EMPTY_COMPOSER, genre: EMPTY_GENRE, instrument: EMPTY_INSTRUMENT, concept: EMPTY_CONCEPT };
        const key = keyMap[activeTab] || activeTab;
        setForms(prev => ({ ...prev, [key]: emptyMap[key] }));
        setShowModal(prev => ({ ...prev, [key]: true }));
    };

    /* ── 저장 핸들러 ── */
    const saveMusic = () => {
        setMusics(forms.music.id
            ? musics.map(m => m.id === forms.music.id ? forms.music : m)
            : [{ ...forms.music, id: Date.now() }, ...musics]);
        setShowModal({ ...showModal, music: false });
    };
    const saveComposer = () => {
        setComposers(forms.comp.id
            ? composers.map(c => c.id === forms.comp.id ? forms.comp : c)
            : [{ ...forms.comp, id: Date.now() }, ...composers]);
        setShowModal({ ...showModal, comp: false });
    };
    const saveGenre = () => {
        setGenres(forms.genre.id
            ? genres.map(g => g.id === forms.genre.id ? forms.genre : g)
            : [{ ...forms.genre, id: Date.now() }, ...genres]);
        setShowModal({ ...showModal, genre: false });
    };
    const saveInstrument = () => {
        setInstruments(forms.instrument.id
            ? instruments.map(i => i.id === forms.instrument.id ? forms.instrument : i)
            : [{ ...forms.instrument, id: Date.now() }, ...instruments]);
        setShowModal({ ...showModal, instrument: false });
    };
    const saveConcept = () => {
        setConcepts(forms.concept.id
            ? concepts.map(c => c.id === forms.concept.id ? forms.concept : c)
            : [{ ...forms.concept, id: Date.now() }, ...concepts]);
        setShowModal({ ...showModal, concept: false });
    };

    /* ── 삭제 핸들러 ── */
    const handleDelete = () => {
        if (!confirm("삭제하시겠습니까?")) return;
        const id = selectedItem.id;
        if      (activeTab === "library")    setMusics(musics.filter(x => x.id !== id));
        else if (activeTab === "composer")   setComposers(composers.filter(x => x.id !== id));
        else if (activeTab === "genre")      setGenres(genres.filter(x => x.id !== id));
        else if (activeTab === "instrument") setInstruments(instruments.filter(x => x.id !== id));
        else if (activeTab === "concept")    setConcepts(concepts.filter(x => x.id !== id));
        setView("list");
    };

    const TAB_LABELS = { library: "보관함", composer: "작곡가", genre: "장르", instrument: "악기", concept: "개념" };

    return (
        <div style={{ minHeight: "100vh" }}>
            <style>{globalStyle}</style>

            {/* ── 헤더 ── */}
            <header>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 20px", height: 55 }}>
                    <div onClick={() => { setActiveTab("library"); setView("list"); setSearchQuery(""); }} style={{ cursor: "pointer", fontWeight: 900, fontSize: 20 }}>
                        POLY<span style={{ color: ACCENT }}>PHONIC</span>
                    </div>
                    <button onClick={openAddModal} style={{ background: ACCENT, color: "#fff", border: "none", borderRadius: 8, padding: "6px 14px", fontSize: 13, fontWeight: 700, cursor: "pointer" }}>
                        + 추가
                    </button>
                </div>

                <div className="search-container">
                    <input className="search-input" placeholder="무엇이든 검색하세요..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
                </div>

                <nav style={{ display: "flex", padding: "0 20px 5px", overflowX: "auto" }} className="scroll-container">
                    {Object.entries(TAB_LABELS).map(([t, label]) => (
                        <button key={t} onClick={() => { setActiveTab(t); setView("list"); setSearchQuery(""); }}
                            style={{ background: "none", border: "none", borderBottom: activeTab === t ? `3px solid ${ACCENT}` : "3px solid transparent", padding: "12px 18px", fontSize: 14, fontWeight: activeTab === t ? 800 : 500, color: activeTab === t ? ACCENT : "#888", cursor: "pointer", whiteSpace: "nowrap" }}>
                            {label}
                        </button>
                    ))}
                </nav>
            </header>

            {/* ── 검색 결과 드롭다운 ── */}
            {searchQuery && (
                <div className="search-results scroll-container" style={{ maxHeight: '70vh', overflowY: 'auto', left: '50%', transform: 'translateX(-50%)' }}>
                    {searchResults.length === 0
                        ? <div style={{ padding: '20px 0', color: '#999', fontSize: 14 }}>검색 결과가 없습니다.</div>
                        : searchResults.map((item, idx) => (
                            <div key={idx} className="search-item" onClick={() => { setSelectedItem(item); setActiveTab(item._type); setView("detail"); setSearchQuery(""); }}>
                                <span className="search-tag">{TAB_LABELS[item._type]?.toUpperCase()}</span>
                                <span style={{ fontSize: 15, fontWeight: 600 }}>{item._title}</span>
                            </div>
                        ))
                    }
                </div>
            )}

            {/* ── 메인 콘텐츠 ── */}
            <main style={{ maxWidth: 720, margin: "0 auto", paddingBottom: 100 }}>

                {/* 목록 뷰 */}
                {view === "list" && (
                    <div>
                        {activeTab === "library" && (
                            musics.length === 0
                                ? <EmptyState label="아직 기록된 음악이 없습니다." />
                                : musics.map(m => (
                                    <div key={m.id} onClick={() => { setSelectedItem(m); setView("detail"); }} style={{ padding: "25px 20px", borderBottom: `1px solid ${BORDER}`, cursor: 'pointer' }}>
                                        <div style={{ fontSize: 11, color: "#888", marginBottom: 5 }}>{m.composer} • {m.genre}</div>
                                        <div style={{ fontSize: 22, fontWeight: 800 }}>{m.musicTitle}</div>
                                        <div style={{ fontSize: 14, color: "#444" }}>《{m.filmTitle}》</div>
                                    </div>
                                ))
                        )}
                        {(activeTab === "composer" || activeTab === "genre" || activeTab === "instrument") && (() => {
                            const list = activeTab === "composer" ? composers : activeTab === "genre" ? genres : instruments;
                            return list.length === 0
                                ? <EmptyState label={`아직 등록된 ${TAB_LABELS[activeTab]}이/가 없습니다.`} />
                                : <div className="grid-layout">{list.map(item => (
                                    <div key={item.id} className="grid-card" onClick={() => { setSelectedItem(item); setView("detail"); }}>
                                        <img src={item.photo || 'https://placehold.co/300x300/f9f9f9/ccc?text=🎵'} className="grid-img" />
                                        <div style={{ fontSize: 14, fontWeight: 700, marginTop: 10 }}>{item.name}</div>
                                    </div>
                                ))}</div>;
                        })()}
                        {activeTab === "concept" && (
                            concepts.length === 0
                                ? <EmptyState label="아직 등록된 개념이 없습니다." />
                                : concepts.map(c => (
                                    <div key={c.id} className="concept-card" onClick={() => { setSelectedItem(c); setView("detail"); }}>
                                        <div style={{ fontSize: 18, fontWeight: 800, color: ACCENT, marginBottom: 5 }}>{c.name}</div>
                                        <div style={{ fontSize: 13, color: "#666" }}>{c.summary}</div>
                                    </div>
                                ))
                        )}
                    </div>
                )}

                {/* 상세 뷰 */}
                {view === "detail" && selectedItem && (
                    <DetailView
                        type={activeTab}
                        data={selectedItem}
                        musics={musics}
                        onBack={() => setView("list")}
                        onHashtagClick={tag => { setTargetHashtag(tag); setView("hashtagPage"); }}
                        onEdit={() => {
                            const keyMap = { library: 'music', composer: 'comp', genre: 'genre', instrument: 'instrument', concept: 'concept' };
                            const key = keyMap[activeTab] || activeTab;
                            setForms({ ...forms, [key]: selectedItem });
                            setShowModal({ ...showModal, [key]: true });
                        }}
                        onDelete={handleDelete}
                    />
                )}

                {/* 해시태그 페이지 */}
                {view === "hashtagPage" && (
                    <div style={{ padding: "20px 25px" }}>
                        <button onClick={() => setView("detail")} style={{ border: "none", background: "none", color: ACCENT, fontWeight: 800, cursor: 'pointer', marginBottom: 20 }}>← 뒤로가기</button>
                        <h1 style={{ fontSize: 28, fontWeight: 900, marginBottom: 30 }}>
                            <span style={{ color: ACCENT }}>{targetHashtag}</span> 검색 결과
                        </h1>
                        {Object.entries(hashtagFilteredData).map(([key, list]) => list.length > 0 && (
                            <div key={key} style={{ marginBottom: 30 }}>
                                <div className="hashtag-group-title">{TAB_LABELS[key]?.toUpperCase()}</div>
                                {key === 'library' ? list.map(m => (
                                    <div key={m.id} onClick={() => { setSelectedItem(m); setActiveTab('library'); setView('detail'); }} style={{ padding: '15px 0', borderBottom: `1px solid ${BORDER}`, cursor: 'pointer' }}>
                                        <div style={{ fontWeight: 700 }}>{m.musicTitle}</div>
                                        <div style={{ fontSize: 12, color: '#999' }}>《{m.filmTitle}》</div>
                                    </div>
                                )) : (
                                    <div className="grid-layout" style={{ padding: '10px 0' }}>
                                        {list.map(item => (
                                            <div key={item.id} className="grid-card" onClick={() => { setSelectedItem(item); setActiveTab(key); setView('detail'); }}>
                                                <img src={item.photo || 'https://placehold.co/300x300/f9f9f9/ccc?text=🎵'} className="grid-img" />
                                                <div style={{ fontSize: 12, fontWeight: 700, marginTop: 5 }}>{item.name}</div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        ))}
                    </div>
                )}
            </main>

            {/* ══ 모달들 ══ */}

            {/* 음악 기록 모달 */}
            {showModal.music && (
                <div className="modal-overlay">
                    <div className="modal-content scroll-container">
                        <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>음악 기록</h2>
                        <Input label="영화 제목"          value={forms.music.filmTitle}  onChange={v => setForms({ ...forms, music: { ...forms.music, filmTitle: v } })} />
                        <Input label="음악 제목"          value={forms.music.musicTitle} onChange={v => setForms({ ...forms, music: { ...forms.music, musicTitle: v } })} />
                        <Input label="날짜"               value={forms.music.date}       onChange={v => setForms({ ...forms, music: { ...forms.music, date: v } })} />
                        <Input label="링크"               value={forms.music.link}       onChange={v => setForms({ ...forms, music: { ...forms.music, link: v } })} />
                        <Input label="작곡가"             value={forms.music.composer}   onChange={v => setForms({ ...forms, music: { ...forms.music, composer: v } })} />
                        <Input label="제작 연도"          value={forms.music.year}       onChange={v => setForms({ ...forms, music: { ...forms.music, year: v } })} />
                        <Input label="장르"               value={forms.music.genre}      onChange={v => setForms({ ...forms, music: { ...forms.music, genre: v } })} />
                        <Input label="맥락"        isArea value={forms.music.context}    onChange={v => setForms({ ...forms, music: { ...forms.music, context: v } })} />
                        <Input label="기능"        isArea value={forms.music.function}   onChange={v => setForms({ ...forms, music: { ...forms.music, function: v } })} />
                        <div style={{ marginBottom: 20 }}>
                            <label className="section-label" style={{ display: 'block', marginBottom: 8 }}>구성 분석</label>
                            <button onClick={() => setShowCompositionLayer(true)} style={{ width: '100%', padding: 12, background: '#f8f8f8', border: `1px dashed ${BORDER}`, borderRadius: 8, color: ACCENT, fontWeight: 600, cursor: 'pointer' }}>
                                구성 분석 입력
                            </button>
                        </div>
                        <Input label="감상 및 질문" isArea value={forms.music.review}    onChange={v => setForms({ ...forms, music: { ...forms.music, review: v } })} />
                        <Input label="스크랩"             value={forms.music.scraps}     onChange={v => setForms({ ...forms, music: { ...forms.music, scraps: v } })} />
                        <Input label="여담"        isArea value={forms.music.anecdotes}  onChange={v => setForms({ ...forms, music: { ...forms.music, anecdotes: v } })} />
                        <Input label="해시태그 (#으로 구분)" value={forms.music.hashtags} onChange={v => setForms({ ...forms, music: { ...forms.music, hashtags: v } })} />
                        <ModalButtons onCancel={() => setShowModal({ ...showModal, music: false })} onSave={saveMusic} />
                    </div>
                </div>
            )}

            {/* 작곡가 등록 모달 */}
            {showModal.comp && (
                <div className="modal-overlay">
                    <div className="modal-content scroll-container">
                        <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>작곡가 등록</h2>
                        <PhotoUpload photo={forms.comp.photo} inputId="c-img" onUpload={e => handleImgUpload(e, 'comp')} />
                        <Input label="이름"       value={forms.comp.name}        onChange={v => setForms({ ...forms, comp: { ...forms.comp, name: v } })} />
                        <Input label="설명" isArea value={forms.comp.description} onChange={v => setForms({ ...forms, comp: { ...forms.comp, description: v } })} />
                        <Input label="특징" isArea value={forms.comp.traits}      onChange={v => setForms({ ...forms, comp: { ...forms.comp, traits: v } })} />
                        <SearchPicker label="참여 작품" list={musics} filterKey="musicTitle" selectedIds={forms.comp.workIds || []}
                            onSelect={id => setForms({ ...forms, comp: { ...forms.comp, workIds: forms.comp.workIds?.includes(id) ? forms.comp.workIds.filter(x => x !== id) : [...(forms.comp.workIds || []), id] } })} />
                        <Input label="여담"  isArea value={forms.comp.anecdotes}  onChange={v => setForms({ ...forms, comp: { ...forms.comp, anecdotes: v } })} />
                        <Input label="스크랩"       value={forms.comp.scraps}     onChange={v => setForms({ ...forms, comp: { ...forms.comp, scraps: v } })} />
                        <Input label="해시태그"     value={forms.comp.hashtags}   onChange={v => setForms({ ...forms, comp: { ...forms.comp, hashtags: v } })} />
                        <ModalButtons onCancel={() => setShowModal({ ...showModal, comp: false })} onSave={saveComposer} />
                    </div>
                </div>
            )}

            {/* 장르 등록 모달 */}
            {showModal.genre && (
                <div className="modal-overlay">
                    <div className="modal-content scroll-container">
                        <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>장르 등록</h2>
                        <PhotoUpload photo={forms.genre.photo} inputId="g-img" onUpload={e => handleImgUpload(e, 'genre')} />
                        <Input label="이름"        value={forms.genre.name}      onChange={v => setForms({ ...forms, genre: { ...forms.genre, name: v } })} />
                        <Input label="개요"  isArea value={forms.genre.summary}  onChange={v => setForms({ ...forms, genre: { ...forms.genre, summary: v } })} />
                        <Input label="특징"  isArea value={forms.genre.traits}   onChange={v => setForms({ ...forms, genre: { ...forms.genre, traits: v } })} />
                        <Input label="여담"  isArea value={forms.genre.anecdotes} onChange={v => setForms({ ...forms, genre: { ...forms.genre, anecdotes: v } })} />
                        <Input label="스크랩"       value={forms.genre.scraps}   onChange={v => setForms({ ...forms, genre: { ...forms.genre, scraps: v } })} />
                        <Input label="해시태그"     value={forms.genre.hashtags} onChange={v => setForms({ ...forms, genre: { ...forms.genre, hashtags: v } })} />
                        <ModalButtons onCancel={() => setShowModal({ ...showModal, genre: false })} onSave={saveGenre} />
                    </div>
                </div>
            )}

            {/* 악기 등록 모달 */}
            {showModal.instrument && (
                <div className="modal-overlay">
                    <div className="modal-content scroll-container">
                        <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>악기 추가</h2>
                        <PhotoUpload photo={forms.instrument.photo} inputId="i-img" onUpload={e => handleImgUpload(e, 'instrument')} />
                        <Input label="이름"           value={forms.instrument.name}     onChange={v => setForms({ ...forms, instrument: { ...forms.instrument, name: v } })} />
                        <Input label="개요"    isArea value={forms.instrument.summary}  onChange={v => setForms({ ...forms, instrument: { ...forms.instrument, summary: v } })} />
                        <Input label="상세"    isArea value={forms.instrument.detail}   onChange={v => setForms({ ...forms, instrument: { ...forms.instrument, detail: v } })} />
                        <Input label="특징"    isArea value={forms.instrument.traits}   onChange={v => setForms({ ...forms, instrument: { ...forms.instrument, traits: v } })} />
                        <Input label="활용"    isArea value={forms.instrument.usage}    onChange={v => setForms({ ...forms, instrument: { ...forms.instrument, usage: v } })} />
                        <Input label="주요 아티스트"  value={forms.instrument.artist}   onChange={v => setForms({ ...forms, instrument: { ...forms.instrument, artist: v } })} />
                        <Input label="여담"    isArea value={forms.instrument.anecdotes} onChange={v => setForms({ ...forms, instrument: { ...forms.instrument, anecdotes: v } })} />
                        <Input label="스크랩"         value={forms.instrument.scraps}   onChange={v => setForms({ ...forms, instrument: { ...forms.instrument, scraps: v } })} />
                        <Input label="해시태그"       value={forms.instrument.hashtags} onChange={v => setForms({ ...forms, instrument: { ...forms.instrument, hashtags: v } })} />
                        <ModalButtons onCancel={() => setShowModal({ ...showModal, instrument: false })} onSave={saveInstrument} />
                    </div>
                </div>
            )}

            {/* 개념 등록 모달 */}
            {showModal.concept && (
                <div className="modal-overlay">
                    <div className="modal-content scroll-container">
                        <h2 style={{ fontSize: 18, fontWeight: 800, marginBottom: 20 }}>개념 추가</h2>
                        <Input label="용어명"          value={forms.concept.name}      onChange={v => setForms({ ...forms, concept: { ...forms.concept, name: v } })} />
                        <Input label="개요"    isArea  value={forms.concept.summary}   onChange={v => setForms({ ...forms, concept: { ...forms.concept, summary: v } })} />
                        <Input label="상세"    isArea  value={forms.concept.detail}    onChange={v => setForms({ ...forms, concept: { ...forms.concept, detail: v } })} />
                        <Input label="활용"    isArea  value={forms.concept.usage}     onChange={v => setForms({ ...forms, concept: { ...forms.concept, usage: v } })} />
                        <Input label="사례 및 여담" isArea value={forms.concept.anecdotes} onChange={v => setForms({ ...forms, concept: { ...forms.concept, anecdotes: v } })} />
                        <Input label="스크랩"          value={forms.concept.scraps}    onChange={v => setForms({ ...forms, concept: { ...forms.concept, scraps: v } })} />
                        <Input label="해시태그"        value={forms.concept.hashtags}  onChange={v => setForms({ ...forms, concept: { ...forms.concept, hashtags: v } })} />
                        <ModalButtons onCancel={() => setShowModal({ ...showModal, concept: false })} onSave={saveConcept} />
                    </div>
                </div>
            )}

            {/* 구성 분석 레이어 */}
            {showCompositionLayer && (
                <div className="modal-overlay" style={{ zIndex: 1100, alignItems: 'center' }}>
                    <div style={{ background: '#fff', width: '90%', maxWidth: 400, borderRadius: 20, padding: 25 }}>
                        <h3 style={{ marginBottom: 20, color: ACCENT }}>구성 분석</h3>
                        {['melody', 'harmony', 'rhythm', 'timbre', 'dynamics'].map(k => (
                            <div key={k} style={{ marginBottom: 12 }}>
                                <label style={{ fontSize: 11, fontWeight: 700, display: 'block', marginBottom: 4 }}>{k.toUpperCase()}</label>
                                <textarea
                                    value={forms.music.composition[k]}
                                    onChange={e => setForms({ ...forms, music: { ...forms.music, composition: { ...forms.music.composition, [k]: e.target.value } } })}
                                    style={{ width: '100%', padding: 8, border: `1px solid ${BORDER}`, borderRadius: 8, resize: 'vertical' }}
                                    rows={2}
                                />
                            </div>
                        ))}
                        <button onClick={() => setShowCompositionLayer(false)} style={{ width: '100%', padding: 12, background: ACCENT, color: '#fff', border: 'none', borderRadius: 8, fontWeight: 700, cursor: 'pointer' }}>완료</button>
                    </div>
                </div>
            )}
        </div>
    );
}

/* ══════════════════════════════════════
   상세 뷰 컴포넌트
══════════════════════════════════════ */
function DetailView({ type, data, musics, onBack, onEdit, onDelete, onHashtagClick }) {
    const [anOpen, setAnOpen] = useState(false);
    const tags = (data.hashtags || "").split(" ").filter(t => t.length > 0);
    const linkedWorks = musics.filter(m => data.workIds?.includes(m.id));

    return (
        <div style={{ padding: "20px 25px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 30 }}>
                <button onClick={onBack} style={{ border: "none", background: "none", color: ACCENT, fontWeight: 700, cursor: 'pointer' }}>← 목록으로</button>
                <div style={{ display: 'flex', gap: 15 }}>
                    <button onClick={onEdit}   style={{ border: "none", background: "none", color: "#999",    fontSize: 13, cursor: 'pointer' }}>수정</button>
                    <button onClick={onDelete} style={{ border: "none", background: "none", color: "#ff4d4f", fontSize: 13, cursor: 'pointer' }}>삭제</button>
                </div>
            </div>

            {data.photo && <img src={data.photo} style={{ width: "100%", aspectRatio: "1/1", borderRadius: 20, objectFit: "cover", marginBottom: 30 }} />}
            <h1 style={{ fontSize: 32, fontWeight: 900, marginBottom: 5 }}>{type === 'library' ? data.musicTitle : data.name}</h1>
            {type === 'library' && <div style={{ fontSize: 20, color: '#666', marginBottom: 20, fontWeight: 500 }}>《{data.filmTitle}》</div>}

            <div style={{ marginBottom: 30 }}>
                {tags.map((tag, i) => (
                    <a key={i} className="hashtag-link" onClick={() => onHashtagClick(tag.startsWith("#") ? tag : "#" + tag)}>
                        {tag.startsWith("#") ? tag : "#" + tag}
                    </a>
                ))}
            </div>

            <div>
                {type === 'library' && (
                    <>
                        <Section label="기록 날짜" content={data.date} />
                        <Section label="감상 링크">
                            {data.link ? <a href={data.link} target="_blank" rel="noopener noreferrer" style={{ color: ACCENT }}>{data.link}</a> : "-"}
                        </Section>
                        <Section label="작곡가"    content={data.composer} />
                        <Section label="제작 연도" content={data.year} />
                        <Section label="장르"      content={data.genre} />
                        <Section label="맥락"      content={data.context} />
                        <Section label="기능"      content={data.function} />
                        <Section label="구성 분석">
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 10 }}>
                                {Object.entries(data.composition || {}).map(([k, v]) => (
                                    <div key={k} style={{ background: '#f9f9f9', padding: '12px', borderRadius: 12, border: `1px solid ${BORDER}` }}>
                                        <div style={{ fontSize: 10, color: ACCENT, fontWeight: 800, marginBottom: 4 }}>{k.toUpperCase()}</div>
                                        <div style={{ fontSize: 13, lineHeight: 1.5 }}>{v || '-'}</div>
                                    </div>
                                ))}
                            </div>
                        </Section>
                        <Section label="감상 및 질문" content={data.review} />
                        <Section label="스크랩"       content={data.scraps} />
                    </>
                )}
                {type === 'composer' && (
                    <>
                        <Section label="설명"     content={data.description} />
                        <Section label="특징"     content={data.traits} />
                        <Section label="참여 작품">
                            {linkedWorks.length > 0 ? linkedWorks.map(m => <div key={m.id}>• {m.musicTitle} ({m.filmTitle})</div>) : "-"}
                        </Section>
                        <Section label="스크랩" content={data.scraps} />
                    </>
                )}
                {type === 'genre' && (
                    <>
                        <Section label="개요"   content={data.summary} />
                        <Section label="특징"   content={data.traits} />
                        <Section label="스크랩" content={data.scraps} />
                    </>
                )}
                {type === 'instrument' && (
                    <>
                        <Section label="개요"          content={data.summary} />
                        <Section label="상세"          content={data.detail} />
                        <Section label="특징"          content={data.traits} />
                        <Section label="활용"          content={data.usage} />
                        <Section label="주요 아티스트" content={data.artist} />
                        <Section label="스크랩"        content={data.scraps} />
                    </>
                )}
                {type === 'concept' && (
                    <>
                        <Section label="개요"   content={data.summary} />
                        <Section label="상세"   content={data.detail} />
                        <Section label="활용"   content={data.usage} />
                        <Section label="스크랩" content={data.scraps} />
                    </>
                )}

                {/* 여담 아코디언 */}
                <div style={{ padding: '20px 0', borderBottom: `1px solid ${BORDER}` }}>
                    <div onClick={() => setAnOpen(!anOpen)} style={{ display: 'flex', justifyContent: 'space-between', cursor: 'pointer', alignItems: 'center' }}>
                        <span className="section-label" style={{ marginBottom: 0 }}>여담 및 실례</span>
                        <span style={{ fontSize: 12, color: ACCENT }}>{anOpen ? '▲ 접기' : '▼ 열기'}</span>
                    </div>
                    {anOpen && <div className="accordion">{data.anecdotes || '내용이 없습니다.'}</div>}
                </div>
            </div>
        </div>
    );
}

/* ══════════════════════════════════════
   공통 UI 컴포넌트
══════════════════════════════════════ */
function Section({ label, content, children }) {
    return (
        <div style={{ padding: "22px 0", borderBottom: `1px solid ${BORDER}` }}>
            <div className="section-label">{label}</div>
            <div style={{ fontSize: 16, lineHeight: 1.8, whiteSpace: "pre-wrap", color: "#333" }}>{content || children || "-"}</div>
        </div>
    );
}

function Input({ label, value, onChange, isArea }) {
    return (
        <div style={{ marginBottom: 20 }}>
            <label className="section-label" style={{ display: 'block', marginBottom: 8 }}>{label}</label>
            {isArea
                ? <textarea value={value} onChange={e => onChange(e.target.value)}
                    style={{ width: "100%", padding: 12, border: `1px solid ${BORDER}`, borderRadius: 12, minHeight: 100, outline: 'none', fontSize: 14, resize: 'vertical', fontFamily: 'inherit' }} />
                : <input type="text" value={value} onChange={e => onChange(e.target.value)}
                    style={{ width: "100%", padding: 12, border: `1px solid ${BORDER}`, borderRadius: 12, outline: 'none', fontSize: 14, fontFamily: 'inherit' }} />
            }
        </div>
    );
}

function PhotoUpload({ photo, inputId, onUpload }) {
    return (
        <div style={{ textAlign: 'center', marginBottom: 20 }}>
            <div style={{ width: 120, height: 120, borderRadius: 15, background: '#f5f5f5', margin: '0 auto 10px', overflow: 'hidden', border: `1px solid ${BORDER}` }}>
                {photo && <img src={photo} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />}
            </div>
            <input type="file" id={inputId} hidden accept="image/*" onChange={onUpload} />
            <label htmlFor={inputId} style={{ fontSize: 12, color: ACCENT, fontWeight: 700, cursor: 'pointer' }}>사진 업로드</label>
        </div>
    );
}

function SearchPicker({ label, list, filterKey, selectedIds, onSelect }) {
    return (
        <div style={{ marginBottom: 22 }}>
            <label className="section-label">{label}</label>
            <div style={{ maxHeight: 100, overflowY: 'auto', border: `1px solid ${BORDER}`, marginTop: 8, borderRadius: 10, padding: 5 }}>
                {list.map(i => (
                    <div key={i.id} onClick={() => onSelect(i.id)}
                        style={{ padding: '8px 12px', fontSize: 12, background: selectedIds.includes(i.id) ? ACCENT_LIGHT : 'none', cursor: 'pointer', borderRadius: 8 }}>
                        {selectedIds.includes(i.id) ? '✓ ' : '+ '}{i[filterKey]}
                    </div>
                ))}
                {list.length === 0 && <div style={{ padding: '8px 12px', fontSize: 12, color: '#999' }}>등록된 항목이 없습니다.</div>}
            </div>
        </div>
    );
}

function ModalButtons({ onCancel, onSave }) {
    return (
        <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
            <button onClick={onCancel} style={{ flex: 1, padding: 16, background: '#f5f5f5', border: 'none', borderRadius: 12, fontWeight: 700, cursor: 'pointer', fontSize: 14 }}>취소</button>
            <button onClick={onSave}   style={{ flex: 2, padding: 16, background: ACCENT, color: '#fff', border: 'none', borderRadius: 12, fontWeight: 800, cursor: 'pointer', fontSize: 14 }}>저장</button>
        </div>
    );
}

function EmptyState({ label }) {
    return (
        <div style={{ textAlign: 'center', padding: '80px 20px', color: '#bbb' }}>
            <div style={{ fontSize: 40, marginBottom: 15 }}>🎵</div>
            <div style={{ fontSize: 14 }}>{label}</div>
        </div>
    );
}

/* ── 앱 마운트 ── */
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Polyphonic />);
